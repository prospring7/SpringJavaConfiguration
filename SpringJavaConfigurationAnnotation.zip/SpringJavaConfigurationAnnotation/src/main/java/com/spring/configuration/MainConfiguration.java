package com.spring.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(CognizantConfiguration.class)
public class MainConfiguration {

}
