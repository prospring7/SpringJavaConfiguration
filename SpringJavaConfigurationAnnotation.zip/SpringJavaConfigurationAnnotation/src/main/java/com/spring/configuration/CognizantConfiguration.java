package com.spring.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cognizant.beans.Bean1;

@Configuration
@ComponentScan(basePackages="com.cognizant.*")
public class CognizantConfiguration {
	@Bean(name="Bean1")
	public Bean1 getBean1(){
		Bean1 bean1=new Bean1();
		return bean1;
	}

}
