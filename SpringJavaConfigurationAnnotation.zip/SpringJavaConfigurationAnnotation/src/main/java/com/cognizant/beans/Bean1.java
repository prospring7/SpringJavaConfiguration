package com.cognizant.beans;

import org.springframework.stereotype.Component;

@Component
public class Bean1 {
	
	public Bean1(){}
	
	public void x(){
		System.out.println("--x--");
	}

}
