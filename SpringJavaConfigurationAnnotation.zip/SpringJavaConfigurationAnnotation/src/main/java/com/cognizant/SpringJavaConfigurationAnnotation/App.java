package com.cognizant.SpringJavaConfigurationAnnotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cognizant.beans.Bean1;
import com.spring.configuration.CognizantConfiguration;
import com.spring.configuration.MainConfiguration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext ioc=new AnnotationConfigApplicationContext(MainConfiguration.class);
    	Bean1 bean1=(Bean1)ioc.getBean("bean1");
    	bean1.x();
    }
}
